package com.portfolio.cmansilla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmansillaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmansillaApplication.class, args);
	}

}

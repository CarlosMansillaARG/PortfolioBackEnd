package com.portfolio.cmansilla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmansillaApplicationTests {

	@Test
	void contextLoads() {
	}

}
